echo "CREACION DEL ARCHIVO BACKUP"
fecha=`date +'%Y-%m-%d'`
backdir="/tmp/backup_uam_proxy"
back_file="/tmp/backup_$fecha"
echo "   Parametros de los backup"
echo "       FECHA: " $fecha
echo "       Directorio temporal: " $backdir
echo "       Archivo final del bakcup: " $back_file
echo "   ****** BACKUP INICIANDO *******"
mkdir $backdir
cp /root/gateway_cambio $backdir/
cp /root/firewall.init $backdir/
cp /root/backup_config.sh $backdir
cp /etc/passwd  $backdir/
cp /etc/shadow  $backdir/
cp /etc/group $backdir/
cp /etc/gshadow $backdir/
cp /etc/host.conf $backdir/
cp /etc/hosts $backdir/
cp /etc/hosts.* $backdir/
cp -R /etc/vsftpd $backdir/
cp /etc/vsftpd.* $backdir/
cp -R /etc/squid/ $backdir/
cp -R /etc/samba/ $backdir/
echo "   ****** COMPACTANDO ARCHIVO *******"
tar -cvf $back_file.tar $backdir 
echo "   ****** COMPRIMIENDO ARCHIVO *******"
gzip $back_file.tar
echo "   ****** COPIANDO ARCHIVOS *******"
cp -f $back_file.tar.gz /root/
cp -f  $back_file.tar.gz  /root/backup_last.tar.gz
echo "   ****** BORRANDO TEMPORALES *******"
rm -Rf $backdir
echo "   ****** COPIANDO BACKUP A DIRECTORIO REMOTO *******"
USER="rmoras%Uam1234"
smbclient -I 172.16.13.6 -U "UAMDC\rmoras"  -c "prompt on;  mput backup_last.tar.gz; dir" //172.16.13.6/backup_firewall
echo "   ****** FIN DE BACKUP *******"
